import time
import random

# Function to print text with a delay between each character
def print_with_delay(text, delay=0.05):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

# Function to display a menu of options
def display_menu(options):
    for i, option in enumerate(options, 1):
        print(f"{i}. {option}")
    print("0. Quit")

# Inventory to store items collected during the game
inventory = []

# Dictionary containing the different rooms in the dungeon and their descriptions, options, and decisions
rooms = {
    "entrance": {
        "description": "You are at the dungeon entrance. There are doors to the north and east.",
        "options": ["Go north to the hallway", "Go east to the armory"],
        "decisions": ["hallway", "armory"]
    },
    "hallway": {
        "description": "You are in the hallway. It's dimly lit and eerie. There are doors to the south, east, and west.",
        "options": ["Go south to the entrance", "Go east to the library", "Go west to the dining room"],
        "decisions": ["entrance", "library", "dining room"]
    },
    "armory": {
        "description": "You are in the armory. There are weapons and armor here. There are doors to the west and north.",
        "options": ["Go west to the entrance", "Go north to the treasure room"],
        "decisions": ["entrance", "treasure room"]
    },
    "library": {
        "description": "You are in the library. It's filled with ancient books. There are doors to the west and north.",
        "options": ["Go west to the hallway", "Go north to the laboratory"],
        "decisions": ["hallway", "laboratory"]
    },
    "treasure room": {
        "description": "You are in the treasure room. It's filled with gold and jewels. There's a door to the south.",
        "options": ["Go south to the armory"],
        "decisions": ["armory"]
    },
    "dining room": {
        "description": "You are in the dining room. There is a grand table set for a feast. There's a door to the east.",
        "options": ["Go east to the hallway"],
        "decisions": ["hallway"]
    },
    "laboratory": {
        "description": "You are in the laboratory. Strange experiments are taking place here. There's a door to the south.",
        "options": ["Go south to the library"],
        "decisions": ["library"]
    }
}

# List of unique events that the player can encounter
unique_events = [
    {"event": "You encountered a sleeping dragon! What do you do?", "choices": ["Sneak past", "Attack it"], "consequences": {"Sneak past": "You successfully sneaked past the dragon!", "Attack it": "The dragon woke up and ate you. Game over."}},
    {"event": "You found a mysterious potion. What do you do?", "choices": ["Drink it", "Save it"], "consequences": {"Drink it": "The potion gave you super strength!", "Save it": "You saved the potion for later and added it to your inventory."}},
    {"event": "You met a talking tree. What do you do?", "choices": ["Talk to it", "Ignore it"], "consequences": {"Talk to it": "The tree gave you a magical seed and added it to your inventory.", "Ignore it": "You ignored the talking tree and moved on."}},
    {"event": "You discovered a hidden trap! What do you do?", "choices": ["Disarm it", "Jump over it"], "consequences": {"Disarm it": "You successfully disarmed the trap.", "Jump over it": "You jumped over the trap but got hurt. You lost some health."}},
    {"event": "You found an ancient map. What do you do?", "choices": ["Study it", "Ignore it"], "consequences": {"Study it": "The map revealed a hidden path!", "Ignore it": "You ignored the map and moved on."}},
    {"event": "You met a lost traveler. What do you do?", "choices": ["Help them", "Ignore them"], "consequences": {"Help them": "The traveler thanked you and gave you a gift.", "Ignore them": "You ignored the traveler and moved on."}},
    {"event": "You encountered a haunted mirror. What do you do?", "choices": ["Look into it", "Break it"], "consequences": {"Look into it": "The mirror showed you a vision of the future.", "Break it": "The mirror shattered into a million pieces."}},
    {"event": "You found a treasure chest. What do you do?", "choices": ["Open it", "Leave it"], "consequences": {"Open it": "The chest contained a rare artifact and added it to your inventory.", "Leave it": "You left the chest and moved on."}},
    {"event": "You met a ghost. What do you do?", "choices": ["Talk to it", "Run away"], "consequences": {"Talk to it": "The ghost revealed a secret passage.", "Run away": "You ran away from the ghost."}},
    {"event": "You discovered a magical portal. What do you do?", "choices": ["Enter it", "Avoid it"], "consequences": {"Enter it": "You entered the portal and found yourself in a new place.", "Avoid it": "You avoided the portal."}},
    {"event": "You found a cryptic message on the wall. What do you do?", "choices": ["Decipher it", "Ignore it"], "consequences": {"Decipher it": "You deciphered the message and found a clue.", "Ignore it": "You ignored the message and moved on."}},
    {"event": "You encountered a band of thieves. What do you do?", "choices": ["Fight them", "Bribe them"], "consequences": {"Fight them": "You fought the thieves and won.", "Bribe them": "You bribed the thieves and they let you go."}},
    {"event": "You found a glowing gem. What do you do?", "choices": ["Take it", "Leave it"], "consequences": {"Take it": "You took the glowing gem and added it to your inventory.", "Leave it": "You left the glowing gem and moved on."}},
    {"event": "You met an old wizard. What do you do?", "choices": ["Ask for help", "Ignore him"], "consequences": {"Ask for help": "The wizard gave you a powerful spell and added it to your inventory.", "Ignore him": "You ignored the wizard and moved on."}},
    {"event": "You found a locked door. What do you do?", "choices": ["Pick the lock", "Search for a key"], "consequences": {"Pick the lock": "You successfully picked the lock.", "Search for a key": "You found a key and unlocked the door."}},
    {"event": "You encountered a giant spider. What do you do?", "choices": ["Fight it", "Run away"], "consequences": {"Fight it": "You fought the giant spider and won.", "Run away": "You ran away from the giant spider."}},
    {"event": "You found a pile of gold coins. What do you do?", "choices": ["Take them", "Leave them"], "consequences": {"Take them": "You took the gold coins and added them to your inventory.", "Leave them": "You left the gold coins and moved on."}},
    {"event": "You met a merchant. What do you do?", "choices": ["Trade with him", "Ignore him"], "consequences": {"Trade with him": "You traded with the merchant.", "Ignore him": "You ignored the merchant and moved on."}},
    {"event": "You found a crystal ball. What do you do?", "choices": ["Gaze into it", "Ignore it"], "consequences": {"Gaze into it": "The crystal ball showed you a vision.", "Ignore it": "You ignored the crystal ball and moved on."}},
    {"event": "You encountered a powerful sorceress. What do you do?", "choices": ["Ask for help", "Fight her"], "consequences": {"Ask for help": "The sorceress gave you a powerful potion and added it to your inventory.", "Fight her": "The sorceress defeated you. Game over."}}
]

# Starting room
current_room = "entrance"
events_done = 0
max_events = 20

# Introductory text
print_with_delay("Welcome to the Dungeon Adventure!", 0.05)
print_with_delay("You must navigate through the dungeon, make choices, and try to survive.", 0.05)
print_with_delay("Good luck!", 0.05)

# Main game loop
while events_done < max_events:
    room = rooms[current_room]
    print_with_delay("\n" + room["description"], 0.05)
    
    # Display the options for the current room
    display_menu(room["options"])

    # Handle room navigation choices
    while True:
        try:
            choice = int(input("Choose an option: "))
            if choice == 0:
                print_with_delay("Thanks for playing!", 0.05)
                exit()
            elif 1 <= choice <= len(room["options"]):
                current_room = room["decisions"][choice - 1]
                break
            else:
                print_with_delay("Invalid choice. Try again.", 0.05)
        except ValueError:
            print_with_delay("Invalid input. Try again.", 0.05)

    # Check if an event should occur
    if random.random() < 0.5:  # 50% chance of an event occurring
        event = unique_events.pop(0)  # Get the next unique event
        print_with_delay("\n" + event["event"], 0.05)
        
        # Display the choices for the event
        display_menu(event["choices"])

        # Handle event choices
        while True:
            try:
                event_choice = int(input("Choose an option: "))
                if event_choice == 0:
                    print_with_delay("Thanks for playing!", 0.05)
                    exit()
                elif 1 <= event_choice <= len(event["choices"]):
                    outcome = event["choices"][event_choice - 1]
                    print_with_delay(event["consequences"][outcome], 0.05)
                    
                    # Handle consequences that add items to inventory
                    if "inventory" in event["consequences"][outcome]:
                        item = event["consequences"][outcome].split(" and ")[-1]
                        inventory.append(item)

                    # End the game if the player dies
                    if "Game over" in event["consequences"][outcome]:
                        print_with_delay("You died. Game over.", 0.05)
                        exit()
                    
                    break
                else:
                    print_with_delay("Invalid choice. You missed the opportunity.", 0.05)
            except ValueError:
                print_with_delay("Invalid input. You missed the opportunity.", 0.05)
        
        # Increment the count of events done
        events_done += 1

# Congratulate the player if they complete the game
print_with_delay("Congratulations! You've survived the dungeon adventure.", 0.05)
